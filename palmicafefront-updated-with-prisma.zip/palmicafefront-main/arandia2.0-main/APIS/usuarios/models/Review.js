/**
 * Christian Santacruz 
 * 
 * David Inguilan
 * 
 * Cafe Arandia 2.0
 * 
 * Modelo - Reseñas
 */

class Review {
    constructor(id, calificacion, comentario, fecha) {
        this.id = id;
        this.calificacion = calificacion;
        this.comentario = comentario;
        this.fecha = fecha;
    }

    crearReseña() {
      
    }

    editarReseña() {
        
    }
}

module.exports = Review;
