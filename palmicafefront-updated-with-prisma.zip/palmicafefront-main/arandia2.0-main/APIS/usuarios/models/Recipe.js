/**
 * Christian Santacruz 
 * 
 * David Inguilan
 * 
 * Cafe Arandia 2.0
 * 
 * Modelo - Recetas
 */
class Recipe {
    constructor(id, calificacion, comentario, fecha) {
        this.id = id;
        this.calificacion = calificacion;
        this.comentario = comentario;
        this.fecha = fecha;
    }

    editarReceta() {
        
    }

    crearReceta() {
        
    }
}

module.exports = Recipe;
