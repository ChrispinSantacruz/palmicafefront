/**
 * Christian Santacruz 
 * 
 * David Inguilan
 * 
 * Cafe Arandia 2.0
 * 
 * Modelo - Ordenes
 */

class Order {
    constructor(id, fecha, estado, total) {
        this.id = id;
        this.fecha = fecha;
        this.estado = estado;
        this.total = total;
    }

    agregarProducto() {
      
    }

    eliminarProducto() {
        
    }

    calcularTotal() {
       
    }

    cambiarEstado() {
        
    }
}

module.exports = Order;
