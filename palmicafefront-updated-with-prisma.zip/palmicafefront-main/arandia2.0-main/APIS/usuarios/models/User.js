/**
 * Christian Santacruz 
 * 
 * David Inguilan
 * 
 * Cafe Arandia 2.0
 * 
 * Modelo - Usuarios
 */

class User {
    constructor(id, nombre, email, contraseña) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.contraseña = contraseña;
    }

    registrar() {
        
    }

    iniciarSesion() {
        
    }
}

module.exports = User;
